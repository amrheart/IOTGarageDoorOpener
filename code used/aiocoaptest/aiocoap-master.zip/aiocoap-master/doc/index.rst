.. include_preprocessed:: ../README.rst

.. toctree::
   :maxdepth: 1

   installation
   guidedtour
   stateofoscore

   api

   examples
   tools
   faq
   news
   LICENSE
