LICENSE
=======

.. include:: ../LICENSE
