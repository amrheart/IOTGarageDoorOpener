"""These modules provide mechanisms shared between different widget demos"""
