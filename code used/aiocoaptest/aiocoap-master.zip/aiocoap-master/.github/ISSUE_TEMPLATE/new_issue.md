---
name: New issue
about: Template for any newly opened issue

---

<!--
Please include the output of `python3 -m aiocoap.cli.defaults` in your report,
run in the environment in which you experienced the issues.
-->
